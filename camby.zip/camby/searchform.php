<form class="search-bar" action="<?php echo home_url(); ?>">
    <input type="text" name="s" class="search-input" value="<?php echo get_search_query(); ?>">
    <button type="submit">
      <i class="fa-solid fa-magnifying-glass"></i>
    </button>
</form>