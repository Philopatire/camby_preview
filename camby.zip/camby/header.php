<?php 
  $page_title = "";
  if (is_archive()) $page_title = get_the_archive_title();
  elseif (is_search()) $page_title = get_search_query();
  elseif (get_query_var("blog_posts")) $page_title = "Blog Posts";
  elseif (is_singular()) $page_title = get_the_title();
  elseif (is_404()) $page_title = "Error 404 Not Found";
?>

<!DOCTYPE html>
<html <?php language_attributes();?>>
  <head>
    <?php wp_head(); ?>
    <meta charset=<?php bloginfo('charset'); ?>>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo bloginfo('name') . ($page_title ? " | " . $page_title : ""); ?></title>
    <style>
      <?php 
        $font = get_theme_mod("font_style");
        $pragraph_size = get_theme_mod("paragraph_size") ? get_theme_mod("paragraph_size") . "px" : "16px";
        $main_btn_theme = get_theme_mod("main_btn_theme") ? get_theme_mod("main_btn_theme") : "dark";
        $main_nav_theme = get_theme_mod("main_nav_theme") ? get_theme_mod("main_nav_theme") : "light";
        $anchor_hover_color = get_theme_mod("anchor_hover_color") ? get_theme_mod("anchor_hover_color") : "#ff0000";
        $body_background = get_theme_mod("body_bg") ? get_theme_mod("body_bg") : "#ffffff"
      ?>
      * {
        font-family: <?php echo $font ? $font : "Red Hat Display" ?>, sans-serif;
      }
      body {
        background-color: <?php echo $body_background ?>
      }
      .paragraph {
        font-size: <?php echo $pragraph_size ?> !important;
      }
      .main-btn {
        <?php if ($main_btn_theme == "light") : ?>
          background-color: #ffffff !important;
          color: #121416 !important;
        <?php elseif ($main_btn_theme == "dark") : ?>
          background-color: #121416 !important;
          color: #ffffff !important;
        <?php endif; ?>
      }
      .main-btn:hover {
        <?php if ($main_btn_theme == "light") : ?>
          background-color: #121416 !important;
          color: #ffffff !important;
        <?php elseif ($main_btn_theme == "dark") : ?>
          background-color: #ffffff !important;
          color: #121416 !important;
        <?php endif; ?>
      }
      .main-nav.background, 
      .results .main-nav, 
      .error404 .main-nav {
        <?php 
          if ($main_nav_theme == "light") echo "background-color: #ffffff";
          elseif ($main_nav_theme == "dark") echo "background-color: #121416";
        ?>
      }
      .main-nav.background .container, 
      .results .main-nav .container, 
      .error404 .main-nav .container {
        <?php 
          if ($main_nav_theme == "light") echo "color: #121416 !important";
          elseif ($main_nav_theme == "dark") echo "color: #ffffff !important";
        ?>
      }
      a:hover, a:active {
        color: <?php echo $anchor_hover_color; ?> !important;
      }
      <?php echo $main_nav_theme; ?>
    </style>
  </head>
  <?php
    $additonal_classes = [];
    if (is_singular()) {
      $additonal_classes[] = "singular";
    } else if (is_archive() || is_search() || get_query_var("blog_posts")) {
      $additonal_classes[] = "results";
      if (get_query_var("blog_posts")) {
        $additonal_classes[] = "blog-posts";
      }
    }
    $body_classes =  array_merge(get_body_class(), $additonal_classes);
  ?>
  <body class='<?php echo implode(" ", $body_classes)?>'>
    <?php wp_body_open(); ?>
    <div class="wrapper">
      <?php get_template_part('templates/content', 'navholder'); ?>
