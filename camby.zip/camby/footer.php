    <div class="footer">
      <p>&copy; <?php echo bloginfo('name') . " " . date("Y") ?>. All right reserved</p>
    </div>
    </div>
    <?php wp_footer(); ?>
  </body>
</html>