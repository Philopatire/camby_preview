<?php get_header(); ?>
  <?php get_template_part("templates/content", "navbar"); ?>
  <?php get_template_part("templates/archive", "landing"); ?>
  <?php get_template_part("templates/archive", "pageholder"); ?>
<?php get_footer(); ?>