<?php
  $posts_count = 9;
  $q = new WP_Query( ["posts_per_page" => $posts_count] );
  if ($q->have_posts()) :
?>
  <div class="last-posts">
      <div class="container">
        <div class="posts-holder">
          <?php
            while ($q->have_posts()) : $q->the_post();
          ?>
            <div class="column">
              <?php get_template_part("templates/content", "post"); ?>
            </div>
          <?php endwhile; ?>
        </div>
        <?php wp_reset_postdata(); ?>
      </div>
    </div>
<?php endif; ?>
