<?php
  $search_bg = get_theme_mod("search_bg") ? get_theme_mod("search_bg") : get_template_directory_uri() . '/assets/images/search.jpg';
?>
<div class="landing">
  <div class="container overlay">
  <?php
    if (!is_home() && !is_front_page() ) {
      get_breadcrumb();
    }
  ?>
    <img class="landing-image" src="<?php echo $search_bg; ?>" alt="">
    <div class="text">
      <h1>Search For : <?php echo get_search_query(); ?></h1>
      <?php get_search_form(); ?>
    </div>
  </div>
</div>