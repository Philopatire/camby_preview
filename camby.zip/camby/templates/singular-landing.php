<div class="landing overlay">
  <?php get_template_part('templates/content', 'navbar'); ?>
  <?php the_post_thumbnail("post-thumbnail", ["class" => "landing-image"]); ?>
  <div class="container">
    <?php 
      if (!is_home() && !is_front_page() ) {
        get_breadcrumb();
      }
    ?>
    <div class="text">
      <h1 class="post-title"><?php the_title(); ?></h1>
      <div class="post-meta">
        <div class="author">
          by <?php the_author_posts_link(); ?>
        </div>
        <?php if(get_the_date()) : ?>
        <div class="horizontal-line"></div>
        <?php $year = get_the_date("Y"); $month = get_the_date("m"); $day = get_the_date("d"); ?>
        <div class="date">
          <a href='<?php echo get_month_link($year, $month); ?>'><?php echo get_the_date("F"); ?></a>
          <a href='<?php echo get_day_link($year, $month, $day); ?>'><?php echo get_the_date("d"); ?></a>,
          <a href='<?php echo get_year_link($year); ?>'><?php echo get_the_date("Y"); ?></a>
        </div>
        <?php endif; ?>
        <?php if (get_the_time()) : ?>
        <div class="horizontal-line"></div>
        <div class="time"><?php echo get_the_time(); ?></div>
        <?php endif; ?>
        <?php if (has_category() && !in_category("uncategorized")) : ?>
        <div class="horizontal-line"></div>
        <div class="categories"><ul><li><?php the_category("</li><li>"); ?></li></ul></div>
        <?php endif; ?>
        <?php if (has_tag()) : ?>
        <div class="horizontal-line"></div>
        <div class="tags"><ul><?php the_tags("<li>", "</li><li>", "</li>"); ?><ul></div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>