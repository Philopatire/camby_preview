<div class="page-holder">
  <div class="container">
    <?php 
      if (have_posts()) :
        while (have_posts()) {
          the_post();
          get_template_part("templates/content", "post");
        }
      else : 
    ?>
    <h3 class="no-post">Sorry no post was found</h3>
    <?php endif; ?>
    <?php get_template_part("templates/content", "pagination"); ?>
  </div>
</div>