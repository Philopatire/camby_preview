<div class="post<?php echo has_post_thumbnail() ? '' : " no-thumbnail" ?>">
<?php the_post_thumbnail('post-thumbnail', "class=thumbnail"); ?>
  <div class="text">
    <?php if (has_tag()) : ?>
    <ul class="tags">
      <?php 
        $badge = has_post_thumbnail() ? "badge" : '';
      the_tags(
        "<li class='". $badge . "'>", "</li><li class='". $badge . "'>", '</li>'); 
        ?>
    </ul>
    <?php endif; ?>
    <?php if (has_category() && !in_category('uncategorized')) : ?>
    <ul class="categories">
      <li>
        <?php the_category("</li><li>"); ?>
      </li>
    </ul>
    <?php endif; ?>
    <h3 class="post-title"><a href="<?php echo get_the_permalink(); ?>"><?php the_title(); ?></a></h3>
    <div class="post-meta">
      <div class="author">
        <?php echo get_avatar( get_the_author_meta( "ID" )); ?>
        <?php the_author_posts_link(); ?>
      </div>
      <div class="horizontal-line"></div>
      <span class="date">
        <?php $year = get_the_date("Y"); $month = get_the_date("m"); $day = get_the_date("d"); ?>
        <a href='<?php echo get_month_link($year, $month); ?>'><?php echo get_the_date("F"); ?></a>
        <a href='<?php echo get_day_link($year, $month, $day); ?>'><?php echo get_the_date("d"); ?></a>,
        <a href='<?php echo get_year_link($year); ?>'><?php echo get_the_date("Y"); ?></a>
      </span>
    </div>
    <p class="post-excerpt paragraph"><?php echo get_the_excerpt(); ?></p>
    <a href="<?php echo the_permalink(); ?>" class="read-more">View Post</a>
  </div>
</div>