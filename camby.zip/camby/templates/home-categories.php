<div class="categories-posts">
	<div class="container">
		<ul class="categories">
			<?php
				$categories =	get_categories();
				foreach ($categories as $category):
					if (strtolower($category->name) != "uncategorized") :
			?>
			<li class=""><?php echo $category->name ?></li>
			<?php endif; endforeach; ?>
		</ul>
		<?php
			foreach ($categories as $category):
				if (strtolower($category->name) != "uncategorized") :
					$posts = get_posts(["post_per_page" => 4, "category" => $category->term_id]);
		?>
		<div class="holder <?php echo $category->name ?>">
			<div class="result <?php echo count($posts) <= 1 ? 'only-one' : '' ?>">
				<?php 
					foreach ($posts as $post) :	
						$index = array_search($post, $posts);
						$post_thumnail_url = get_the_post_thumbnail_url($post->ID);
						$post_title = $post->post_title;
						$post_date = get_the_date('F d, Y', $post->ID);
						$post_content = implode(" ", array_slice(explode(" ", $post->post_content), 0, 20)) . "...";
						$post_link = get_permalink($post->ID);
				?>
				<?php if ($index == 1) : ?>
					<div class="column">
				<?php endif; ?>

				<div class="post <?php echo $post_thumnail_url ? "" : "no-thumbnail"; echo $index == 0 ? " large" : ""; ?>">
					<?php if ($post_thumnail_url) : ?>
						<img src='<?php echo $post_thumnail_url ?>' class="post-thumbnail">
					<?php endif; ?>
					<div class="text">
						<div class="date"><?php echo $post_date ?></div>
						<a href="<?php echo $post_link; ?>" class="post-title"><?php echo $post_title; ?></a>
						<div class="post-description"><?php echo $post_content; ?></div>
						<a href="<?php echo $post_link; ?>" class="read-more">View post</a>
					</div>
				</div>
				<?php if ($index == count($posts) - 1 && $index != 0) : ?>
					</div>
				<?php endif; ?>
				<?php endforeach; ?>
			</div>
			<div class="other">
				<?php $other_reads_title = get_theme_mod("random_reads_title") ? get_theme_mod("random_reads_title") : "Other reads"; ?>
				<span class="section-title"><?php echo $other_reads_title; ?></span>
				<?php
					$q = new WP_Query(['orderby' => 'rand', 'posts_per_page' => '3']);
					while ($q->have_posts()):
						$q->the_post();
				?>
				<div class="post <?php echo has_post_thumbnail() ? '' : 'no-thumbnail' ?>">
					<?php the_post_thumbnail("post-thumbnail", "class=post-thumbnail"); ?>
					<div class="text">
						<a href="<?php the_permalink(); ?>"class="post-title"><?php the_title(); ?></a>
						<div class="date"><?php echo get_the_date(); ?></div>
						<p class="post-description"><?php echo get_the_excerpt(); ?></p>
						<a href="<?php the_permalink(); ?>" class="read-more">View post</a>
					</div>
				</div>
				<?php endwhile; wp_reset_postdata();?>
			</div>
		</div>
		<?php endif; endforeach; ?>
	</div>
</div>