<div class="nav-holder" id="main_nav_holder">
  <div class="holder-title">
  <a class="logo" href="<?php echo home_url(); ?>"><?php bloginfo('name'); ?></a>
  <button class="close-menu" id="close_main_nav"><i class="fa-solid fa-xmark"></i></button>
  </div>
  <?php get_search_form(); ?>
  <?php
    wp_nav_menu([
      "theme_location" => 'header-nav',
      "container" => '',
      "menu_id" => '',
      "menu_class" => 'nav-links show'
    ])
  ?>
</div>