<?php
  $landing_image = get_theme_mod("home_landing_bg") ? get_theme_mod("home_landing_bg") : get_template_directory_uri() . "/assets/images/landing.jpg" ;
  $landing_title = get_theme_mod("home_heading") ? get_theme_mod("home_heading") : "A Great Way To Start Your Blogging Journey!";
  $landing_desc = get_bloginfo("description");
  $landing_btn = get_theme_mod("blog_btn") ? get_theme_mod("blog_btn") : "See blog posts"; ;
?>

<div class="landing overlay">
  <img class="landing-image" src="<?php echo $landing_image; ?>">
  <?php get_template_part('templates/content', 'navbar'); ?>
  <div class="container">
    <h1><?php echo $landing_title; ?></h1>
    <?php if ($landing_desc) : ?><p class="description"><?php echo $landing_desc; ?></p> <?php endif; ?>
    <a href="<?php echo home_url() . '/?blog_posts=true' ?>" class="main-btn"><?php echo $landing_btn; ?></a>
  </div>
</div>