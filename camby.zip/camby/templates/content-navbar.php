<div class="main-nav">
  <div class="container">
    <a class="logo" href="<?php echo home_url(); ?>"><?php bloginfo('name'); ?></a>
    <button class="open-menu" id="open_main_nav"><i class="fa-solid fa-bars"></i></button>
  </div>
</div>