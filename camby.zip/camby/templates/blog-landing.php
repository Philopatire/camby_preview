<?php
  $blog_bg = get_theme_mod("blog_bg") ? get_theme_mod("blog_bg") : get_template_directory_uri() . '/assets/images/blog.jpg';
  $blog_desc = get_bloginfo("description");
?>

<div class="landing">
  <div class="container overlay">
  <?php
    if (( !is_home() && !is_front_page() ) || get_query_var("blog_posts") ) {
      get_breadcrumb();
    }
  ?>
    <img class="landing-image" src="<?php echo $blog_bg; ?>" alt="">
    <div class="text">
      <div class="badge-it">Blog</div>
      <h1>Blog Posts</h1>
      <?php if ($blog_desc) : ?><p class="description"><?php echo $blog_desc ?></p> <?php endif; ?>
    </div>
  </div>
</div>