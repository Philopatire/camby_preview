<div class="page-holder">
  <div class="container">
    <div class="row">
      <div class="page-content">
        <button class="open-sidebar" id="open_right_sidebar">
        <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fill="none">
          <g fill="#000000">
          <path d="M11.726 5.263a.7.7 0 10-.952-1.026l-3.5 3.25a.7.7 0 000 1.026l3.5 3.25a.7.7 0 00.952-1.026L8.78 8l2.947-2.737z"/>
          <path fill-rule="evenodd" d="M1 3.25A2.25 2.25 0 013.25 1h9.5A2.25 2.25 0 0115 3.25v9.5A2.25 2.25 0 0112.75 15h-9.5A2.25 2.25 0 011 12.75v-9.5zm2.25-.75a.75.75 0 00-.75.75v9.5c0 .414.336.75.75.75h1.3v-11h-1.3zm9.5 11h-6.8v-11h6.8a.75.75 0 01.75.75v9.5a.75.75 0 01-.75.75z" clip-rule="evenodd"/>
          </g>
        </svg>
        </button>
        <div class="post-content">
          <?php the_content(); ?>
        </div>
        <?php if (!post_password_required() && is_single()) : ?>
          <button class="toggle-comments <?php echo !get_comments_number() ? 'empty' : '' ?>" id="toggle_comments">
            <span><?php echo get_comments_number() ? "View comments" : "Leave a comment" ?></span>
            <?php if (get_comments_number()) echo "(" . get_comments_number() . ")" ?>
          </button>
          <?php comments_template(); ?>
        <?php endif; ?>
      </div>
      <div class="sidebar right-sidebar">
        <div class="sidebar-title">
          <h3>Sidebar</h3>
          <button class="close-sidebar" id="close_right_sidebar">
            <svg viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fill="none">
              <g fill="#000000">
              <path d="M7.774 5.263a.7.7 0 11.952-1.026l3.5 3.25a.7.7 0 010 1.026l-3.5 3.25a.7.7 0 01-.952-1.026L10.72 8 7.774 5.263z"/>
              <path fill-rule="evenodd" d="M1 3.25A2.25 2.25 0 013.25 1h9.5A2.25 2.25 0 0115 3.25v9.5A2.25 2.25 0 0112.75 15h-9.5A2.25 2.25 0 011 12.75v-9.5zm2.25-.75a.75.75 0 00-.75.75v9.5c0 .414.336.75.75.75h1.3v-11h-1.3zm9.5 11h-6.8v-11h6.8a.75.75 0 01.75.75v9.5a.75.75 0 01-.75.75z" clip-rule="evenodd"/>
              </g>
            </svg>
          </button>
        </div>
        <?php dynamic_sidebar('right-sidebar'); ?>
      </div>
    </div>
    <?php if(is_single()) : ?>
      <div class="navigation">
        <p class="previous-post"><?php previous_post_link('<i class="fa-solid fa-chevron-left"></i> %link'); ?></p>
        <p class="next-post"><?php next_post_link('%link <i class="fa-solid fa-chevron-right"></i>'); ?></p>
      </div>
    <?php endif; ?>
  </div>
</div>