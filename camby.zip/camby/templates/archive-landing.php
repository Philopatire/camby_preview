<?php
  $archive_bg = get_theme_mod("archive_bg") ? get_theme_mod("archive_bg") : get_template_directory_uri() . '/assets/images/archive.jpg'
?>

<div class="landing">
  <div class="container overlay">
  <?php
    if (!is_home() && !is_front_page() ) {
      get_breadcrumb();
    }
  ?>
    <img class="landing-image" src="<?php echo $archive_bg; ?>" alt="">
    <div class="text">
      <div class="badge-it"><?php echo get_archive_type() ?></div>
      <?php if (is_author()) echo get_avatar(get_the_author_meta( "ID" )); ?>
      <h1><?php the_archive_title(); ?></h1>
      <p class="description"><?php the_archive_description(); ?></p>
    </div>
  </div>
</div>