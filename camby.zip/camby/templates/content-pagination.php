<?php
 global $wp_query;

  if( $wp_query->max_num_pages <= 1 ) return;

  $paged = get_current_page_number();
  $max   = $wp_query->max_num_pages;
  $links = [];

  for ($i = 1; $i <= $max; $i++) {
    $links[$i] = get_pagenum_link($i);
  }

  ?>

<ul class="pagination">
  <?php if (get_previous_posts_link()) : ?>
    <li> <?php previous_posts_link("Previous"); ?></li>
  <?php endif; ?>

  <?php foreach ($links as $page => $link): ?>
    <li class="<?php echo $page == $paged ? "active" : "" ?>">
      <a href="<?php echo $link; ?>">
        <?php echo $page; ?>
      </a>
    </li>
  <?php endforeach; ?>

  <?php if (get_next_posts_link()) : ?>
    <li><?php next_posts_link("Next"); ?></li>
  <?php endif; ?>
</div>
