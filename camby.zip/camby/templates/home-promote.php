<?php
  $promote_image = get_theme_mod("promote_bg") ? get_theme_mod("promote_bg") : get_template_directory_uri() . '/assets/images/promote.jpg';
  $promote_badge = get_theme_mod("promote_badge") ? get_theme_mod("promote_badge") : "Promote";
  $promote_title = get_theme_mod("promote_title") ? get_theme_mod("promote_title") : "Promote section has attractive heading";
  $promote_desc = get_theme_mod("promote_desc") ? get_theme_mod("promote_desc") : "Unlock a world of inspiration and knowledge on our blog! Immerse yourself in captivating stories, valuable insights, and endless creativity. Join our community and elevate your online experience. Explore, engage, and embark on a journey of discovery with our carefully curated content. Your daily dose of inspiration awaits – promote your passion for learning and growth today!";
  $promote_btn = get_theme_mod("blog_btn") ? get_theme_mod("blog_btn") : "See blog posts";
?>

<div class="promote overlay">
  <img src="<?php echo $promote_image ?>" alt="" class="promote-image">
  <div class="container">
    <div class="text">
      <span class="badge"><?php echo $promote_badge; ?></span>
      <h2 class="promote-title"><?php echo $promote_title ?></h2>
      <p class="promote-description paragraph"><?php echo $promote_desc ?></p>
      <a href="<?php echo home_url() . '/?blog_posts=true' ?>" class="main-btn"><?php echo $promote_btn ?></a>
    </div>
  </div>
</div>