<?php
function typography($wp_customize) {
  $wp_customize->add_section('typography_section', [
    "title" => __("Typography"),
    "description" => __("Edit font style and size"),
    "panel" => "camby_panel",
  ]);

  $wp_customize->add_setting('font_style', [
    "type" => "theme_mod",
    "default" => "Red Hat Display",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control('font_style', [
    "type" => "select",
    "label" => __("Font Style"),
    "choices" => [
      "Red Hat Display" => "Red Hat Display",
      "Arial" => __("Arial"),
      "Verdana" => __("Verdana"),
      "Tahoma" => __("Tahoma"),
      "Times New Roman" => __("Times New Roman"),
    ],
    "section" => "typography_section",
  ]);

  $wp_customize->add_setting("paragraph_size", [
    "type" => "theme_mod",
    "default" => "16",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control("paragraph_size", [
    "type" => "range",
    "label" => __("Paragraph Size"),
    "input_attrs" => [
      "min" => "14",
      "max" => "25",
    ],
    "section" => "typography_section",
  ]);
}

function colors($wp_customize) {
  $wp_customize->add_section("colors_section", [
    "title" => __("Colors"),
    "description" => __("Blog Colors"),
    "panel" => "camby_panel",
  ]);

  $wp_customize->add_setting("main_btn_theme", [
    "type" => "theme_mod",
    "default" => "dark",
    "transport" => "refresh"
  ]);
  $wp_customize->add_control("main_btn_theme", [
    "type" => "radio",
    "label" => __("Main Button Theme"),
    "choices" => [
      "light" => __("Light Theme"),
      "dark" => __("Dark Theme"),
    ],
    "section" => "colors_section",
  ]);

  $wp_customize->add_setting("main_nav_theme", [
    "type" => "theme_mod",
    "default" => "light",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control("main_nav_theme", [
    "type" => "radio",
    "label" => __("Navbar Theme"),
    "choices" => [
      "light" => __("Light Theme"),
      "dark" => __("Dark Theme")
    ],
    "section" => "colors_section",
  ]);

  $wp_customize->add_setting("anchor_hover_color", [
    "type" => "theme_mod",
    "default" => "#ff0000",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, "anchor_hover_color", [
    "label" => __("Link Color"),
    "description" => __("The color of the link changes when the computer mouse hovers over it or when the user clicks on it on a mobile device."),
    "section" => "colors_section",
  ]));
}

function backgrounds($wp_customize) {
  $wp_customize->add_section("bg_section", [
    "title" => __("Backgrounds"),
    "description" => __("The backgrounds of the blog"),
    "panel" => "camby_panel",
  ]);

  $wp_customize->add_setting("body_bg", [
    "type" => "theme_mod",
    "default" => "#ffffff",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, "body_bg", [
    "label" => __("Body background color"),
    "section" => "bg_section",
  ]));

  $wp_customize->add_setting("home_landing_bg", [
    "type" => "theme_mod",
    "default" => get_template_directory_uri() . "/assets/images/landing.jpg",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "home_landing_bg", [
    "label" => __("Home header background image"),
    "section" => "bg_section",
  ]));

  $wp_customize->add_setting("promote_bg", [
    "type" => "theme_mod",
    "default" => get_template_directory_uri() . "/assets/images/promote.jpg",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "promote_bg", [
    "label" => __("Promote section background image"),
    "description" => __("Promote section in the home page"),
    "section" => "bg_section",
  ]));

  $wp_customize->add_setting("archive_bg", [
    "type" => "theme_mod",
    "default" => get_template_directory_uri() . "/assets/images/archive.jpg",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "archive_bg", [
    "label" => __("Archive Page Background Image"),
    "description" => __("The archive page that hold (author, date, category, tag) posts"),
    "section" => "bg_section",
  ]));

  $wp_customize->add_setting("search_bg", [
    "type" => "theme_mod",
    "default" => get_template_directory_uri() . "/assets/images/search.jpg",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "search_bg", [
    "label" => __("Search Page Background Image"),
    "description" => __("The archive page that give search results"),
    "section" => "bg_section",
  ]));

  $wp_customize->add_setting("blog_bg", [
    "type" => "theme_mod",
    "default" => get_template_directory_uri() . "/assets/images/blog.jpg",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "blog_bg", [
    "label" => __("Blog Page Background Image"),
    "description" => __("The blog page that give all posts in your blog"),
    "section" => "bg_section",
  ]));
}

function headings_and_descriptions($wp_customize) {
  $wp_customize->add_section("headings_description_section", [
    "title" => __("Headings & descriptions"),
    "description" => __("The heading and description texts"),
    "panel" => "camby_panel",
  ]);

  $wp_customize->add_setting("home_heading", [
    "type" => "theme_mod",
    "default" => "A Great Way To Start Your Blogging Journey!",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control("home_heading", [
    "type" => "text",
    "label" => __("Home heading text"),
    "section" => "headings_description_section",
  ]);

  $wp_customize->add_setting("blog_btn", [
    "type" => "theme_mod",
    "default" => "See blog posts",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control("blog_btn", [
    "type" => "text",
    "label" => __("Blog button"),
    "section" => "headings_description_section",
  ]);

  $wp_customize->add_setting("promote_badge", [
    "type" => "theme_mod",
    "default" => "Promote",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control("promote_badge", [
    "type" => "text",
    "label" => __("Promote badge"),
    "description" => __("The 'promote' text in the promote section"),
    "section" => "headings_description_section",
  ]);

  $wp_customize->add_setting("promote_title", [
    "type" => "theme_mod",
    "default" => "Promote section has attractive heading",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control("promote_title", [
    "type" => "text",
    "label" => __("Promote title"),
    "description" => __("Promote section title"),
    "section" => "headings_description_section",
  ]);

  $wp_customize->add_setting("promote_desc", [
    "type" => "theme_mod",
    "default" => "Unlock a world of inspiration and knowledge on our blog! Immerse yourself in captivating stories, valuable insights, and endless creativity. Join our community and elevate your online experience. Explore, engage, and embark on a journey of discovery with our carefully curated content. Your daily dose of inspiration awaits – promote your passion for learning and growth today!",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control("promote_desc", [
    "type" => "textarea",
    "label" => __("Promote Description"),
    "section" => "headings_description_section",
  ]);

  $wp_customize->add_setting("random_reads_title", [
    "type" => "theme_mod",
    "default" => "Other reads",
    "transport" => "refresh",
  ]);
  $wp_customize->add_control("random_reads_title", [
    "type" => "text",
    "label" => __("Random reads section title"),
    "description" => __("Warning: This section only appear in the desktop version"),
    "section" => "headings_description_section",
  ]);
}

function register_customizer($wp_customize) {
  $wp_customize->add_panel('camby_panel', [
    "title" => __("Camby Customize"),
    "description" => __("Edit all the text and images"),
    "priority" => 1,
  ]);

  typography($wp_customize);
  colors($wp_customize);
  backgrounds($wp_customize);
  headings_and_descriptions($wp_customize);
}

add_action('customize_register', 'register_customizer');
