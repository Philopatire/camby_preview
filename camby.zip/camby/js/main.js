let btnOpenMainNav = document.getElementById("open_main_nav");
let btnCloseMainNav = document.getElementById("close_main_nav");
let mainNavHolder = document.getElementById("main_nav_holder");

btnOpenMainNav.addEventListener("click", () => {
  mainNavHolder.classList.toggle("show");
});
btnCloseMainNav.addEventListener("click", () => {
  mainNavHolder.classList.remove("show");
});

function handleNavbar() {
  let landing = document.querySelector(".landing")
  let mainNavbar = document.querySelector(".main-nav")
  if (scrollY > landing.offsetHeight - mainNavbar.offsetHeight) {
    mainNavbar.classList.add("background")
  } else {
    mainNavbar.classList.remove("background");
  }
}

addEventListener("scroll", handleNavbar);
handleNavbar();