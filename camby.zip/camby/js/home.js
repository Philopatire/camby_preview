let postsCnt = document.querySelector(".posts-holder");
let posts = [...document.querySelectorAll(".posts-holder .post")];


function createColumn(els, postsCnt) {
  let column = document.createElement("div");
  column.classList.add("column");
  column.append(...els);
  postsCnt.appendChild(column);
}

function arrangePosts(posts) {
  if (posts.length == 0) return;
  let resArr = [];
  let arr = [];
  posts.forEach((el, i) => {
    let screen = innerWidth;
    let colNumber;

    if (screen < 768) colNumber = 1;
    else if (screen < 1400) colNumber = 2;
    else colNumber = 3;

    if (arr.length < Math.ceil(posts.length / colNumber)) {
      arr.push(el);
    } else {
      resArr.push(arr);
      arr = [];
      arr.push(el);
    }
  });
  resArr.push(arr);
  postsCnt.innerHTML = "";
  resArr.forEach((arr) => createColumn(arr, postsCnt));
}

window.addEventListener("resize", () => arrangePosts(posts));
arrangePosts(posts);

let categoriesBtn = [...document.querySelectorAll(".categories-posts .categories li")];
let categoriesHolders = [...document.querySelectorAll(".categories-posts .holder")];

function filterCategory(className, categoriesHolders) {
  categoriesHolders.forEach((holder) => {
    if (!holder.classList.contains(className)) holder.style.display = "none"
    else holder.style.display = ""
  })
} 

categoriesBtn[0].classList.add("active");
filterCategory(categoriesBtn[0].textContent, categoriesHolders);

categoriesBtn.forEach(li => {
  li.addEventListener("click", () => {
    categoriesBtn.forEach(el => {
      el.classList.remove("active")
      if (li.isEqualNode(el)) el.classList.add('active')
    })
    filterCategory(li.textContent, categoriesHolders)
  })
})