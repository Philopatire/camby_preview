let rightSidebarOpenBtn = document.getElementById("open_right_sidebar");
let rightSidebarCloseBtn = document.getElementById("close_right_sidebar");
let rightSidebar = document.querySelector(".right-sidebar")

rightSidebarOpenBtn.addEventListener("click", () => {
  rightSidebar.classList.add("open");
})

rightSidebarCloseBtn.addEventListener("click", () => {
  rightSidebar.classList.remove("open");
})

let btnToggleComments = document.getElementById("toggle_comments")
let commentsHolder = document.querySelector(".comments-holder")

btnToggleComments.addEventListener("click", () => {
  commentsHolder.classList.toggle("show")
  let buttonTxt;
  if (commentsHolder.classList.contains("show")) buttonTxt = "Hide comments";
  else if (btnToggleComments.classList.contains("empty")) buttonTxt = "Leave a comment";
  else buttonTxt = "View comments";
  btnToggleComments.firstElementChild.textContent = buttonTxt
})