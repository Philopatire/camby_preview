<?php get_header(); ?>
<?php get_template_part('templates/content', 'navbar'); ?>
<div class="page-holder">
  <div class="container">
    <h1>404</h1>
    <h2>Page not found</h2>
    <p class="message">Oops! The page you are looking for does not exist. It might have been moved or deleted.</p>
    <a href="<?php echo home_url(); ?>" class="go-home main-btn">Back To Home</a>
  </div>
</div>
<?php get_footer(); ?>