<?php get_header(); ?>
<style>
  .main-nav {
    position: relative;
  }
  .main-nav{
    color: #fff;
    background-color: #121416;
  }
  .wrapper {
    display: flex;
    flex-direction: column;
  }
  .page-holder {
    flex-grow: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
  }
  .page-holder h1 {
    font-size: 200px;
  }
  .page-holder h2 {
    font-size: 42px;
    margin-bottom: 18px;
  }

  .main-btn {
    margin-top: 75px;
    border: 1px solid #121416;
    padding: 15px 30px;
    text-transform: uppercase;
    font-weight: 700;
    transition: 300ms;
    background-color: #ffffff;
  }
  .main-btn > a {
    color: #ffffff !important;
  }
  .main-btn:hover {
    color: #ffffff !important;
    background-color: #121416 !important;
  }
</style>
<?php get_template_part('templates/content', 'navbar'); ?>
<div class="page-holder">
  <div class="container">
    <h2>Error while sending the comment</h2>
    <div class="message"><?php echo $message ?></div>
    <a href="<?php echo home_url(); ?>" class="go-home main-btn">Back To Home</a>
  </div>
</div>
<?php get_footer(); ?>