<?php
function enqueue_styles() {
  wp_enqueue_style("main-style", get_template_directory_uri() . "/style.css");
  wp_enqueue_style("google-font", 'https://fonts.googleapis.com/css2?family=Red+Hat+Display:ital,wght@0,300..900;1,300..900&display=swap');
  wp_enqueue_style("font-awesome", 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css');
};

function enqueue_scripts() {
  wp_enqueue_script("main-script", get_template_directory_uri() . "/js/main.js", [], "", true);
  
  if (is_home() && !get_query_var("blog_posts")) {
    wp_enqueue_script("home-script", get_template_directory_uri() . "/js/home.js", [], "", true);
  }
  if (is_singular()) {
    wp_enqueue_script("home-script", get_template_directory_uri() . "/js/singular.js", [], "", true);
  }
  if (is_single()) {
    wp_enqueue_script('comment-reply');
  }
};

function preconnect_links() {
  echo '
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  ';
};

function register_custom_nav_menus() {
  register_nav_menu('header-nav',__( 'The main navbar' ));
}

function register_custom_sidebar() {
  register_sidebar([
    'name'          => __("Right Sidebar"),
    'id'            => 'right_sidebar',
    'description'   => 'This is the right sidebar.',
    'before_widget' => '<div class="widget">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4 class="widget-title">',
    'after_title'   => '</h4>',
  ]);
}

function excerpt_more_modify() {
  return "";
}

function excerpt_length_modify($length) {
  return 30;
}

function custom_breadcrumb_separator() {
  echo '<span class="custom-breadcrumb-separator"> <i class="fa-solid fa-chevron-right"></i> </span>';
}

function get_current_page_number() {
  return get_query_var( 'paged' ) ? absint(get_query_var( 'paged' )) : 1;
}

function get_archive_type() {
  $type = "";
  if (!is_archive()) return;
  if (is_category()) $type = "category";
  else if (is_tag()) $type = "tag";
  else if (is_author()) $type = "author";
  else if (is_tax()) $type = "tax";
  else if (is_day()) $type = "day";
  else if (is_month()) $type = "month";
  else if (is_year()) $type = "year";
  else if (is_post_type_archive()) $type = "Archive post";
  return $type;
}

function get_breadcrumb() {
  echo "<p id='breadcrumbs'>";
  echo '<span><a href="'. home_url() .'" rel="nofollow">Home</a></span>';
  custom_breadcrumb_separator();
  if (is_singular()) {
    echo '<span>'. get_the_title() .'</span>';
  } else if (is_archive()) {
    echo '<span>'. get_archive_type() .'</span>';
    custom_breadcrumb_separator();
    echo '<span>' . get_the_archive_title() . '</span>';
  } else if (is_search()) {
    echo "<span> Search For </span>";
    custom_breadcrumb_separator();
    echo "<span>" . get_search_query() . "</span>";
  } else if (get_query_var("blog_posts")) {
    echo "<span>Blog</span>";
  }

  if (get_current_page_number() > 1) {
    custom_breadcrumb_separator();
    echo '<span> Page ' . get_current_page_number() . '</span>';
  } 
  echo "</p>";
}

function custom_comments($comment, $args, $depth) {
  echo '<div class="comment-holder" id="comment-'. get_comment_ID() . '" >';
    echo '<div class="comment-title">';
      echo '<div class="author">';
        echo get_avatar($comment) ;
        echo '<span class="author-name">';
          echo get_comment_author($comment);
        echo '</span>';
      echo '</div>';
      echo '<div class="date">';
        echo get_comment_date() ;
        echo '<span>&nbsp;at&nbsp;</span>'; 
        echo get_comment_time();
      echo '</div>';
      echo '<div class="buttons-holder">'; 
        if (current_user_can("edit_comment", $comment)){
          echo '<div class="edit-comment">';
            echo '<i class="fa-solid fa-pen-to-square"></i>';
            echo '<span class="edit-link"><a href="'. get_edit_comment_link() . '">Edit</a></span>';
          echo '</div>';
        };
        if (comments_open()){
          echo '<div class="reply">';
            echo '<i class="fa-solid fa-reply"></i>';
            echo get_comment_reply_link([
                'depth'     => $depth,
                'max_depth' => $args['max_depth'],
                'reply_text' => "Reply",
            ]);
          echo '</div>';
        }
      echo '</div>';
    echo '</div>';
    echo '<p class="comment-content">';
      echo get_comment_text(); 
    echo '</p>';
  echo '</div>';
}

function retrieve_archive_title($title) {
  if (is_category()) {
    $title = single_cat_title('', false);
  } else if (is_tag()) {
      $title = single_tag_title('', false);
  } else if (is_author()) {
      $title = get_the_author();
  } else if (is_tax()) {
      $title = single_term_title('', false);
  } else if (is_day()) {
      $title = get_query_var('day') . " " . date('F', mktime(0, 0, 0, intval(get_query_var("monthnum")), 10)) . " " . get_query_var("year");
  } else if (is_month()) {
      $title = date('F', mktime(0, 0, 0, intval(get_query_var("monthnum")), 10)) . " " . get_query_var("year");
  } else if (is_year()) {
      $title = get_query_var("year");
  } else if (is_post_type_archive()) {
      $title = post_type_archive_title('', false);
  }
  return $title;
}

function add_blog_posts_query_var($queryVars) {
  $queryVars[] = 'blog_posts';
  return $queryVars;
}

function custom_comment_error( $message, $title='', $args=array() ) {
  $errorTemplate = get_theme_root().'/'.get_template().'/commenterror.php';

  if ( function_exists( 'is_wp_error' ) && is_wp_error( $message ) ) {
    if ( empty( $title ) ) {
      $error_data = $message->get_error_data();
      if ( is_array( $error_data ) && isset( $error_data['title'] ) )
        $title = $error_data['title'];
    }
    $errors = $message->get_error_messages();
    switch ( count( $errors ) ) {
    case 0 :
      $message = '';
      break;
    case 1 :
      $message = "<p>{$errors[0]}</p>";
      break;
    default :
      $message = "<ul>\n\t\t<li>" . join( "</li>\n\t\t<li>", $errors ) . "\n\t";
      break;
    }

  } elseif ( is_string( $message ) ) {
    $message = "<p>$message</p>";
  }

  require_once( $errorTemplate );
  die();
}

function get_custom_comment_error() {
  return 'custom_comment_error';
}

add_action('wp_enqueue_scripts', 'enqueue_styles');
add_action('wp_enqueue_scripts', 'enqueue_scripts');
add_action('wp_head', 'preconnect_links');
add_action('init', 'register_custom_nav_menus' );
add_action('widgets_init', 'register_custom_sidebar' );
add_filter('excerpt_more', 'excerpt_more_modify');
add_filter('excerpt_length', 'excerpt_length_modify');
add_filter('get_the_archive_title', 'retrieve_archive_title');
add_filter('query_vars', 'add_blog_posts_query_var');
add_filter( 'wp_die_handler', 'get_custom_comment_error' );
add_theme_support('post-thumbnails');

require_once "assets/php/customizer.php";