<?php get_header(); ?>
  <?php while (have_posts()) : ?>
    <?php the_post(); ?>
    <?php get_template_part('templates/singular', 'landing'); ?>
    <?php get_template_part('templates/singular', 'pageholder'); ?>
  <?php endwhile; ?>
<?php get_footer(); ?>