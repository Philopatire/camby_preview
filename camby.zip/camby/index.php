<?php get_header(); ?>
  <?php if (!get_query_var("blog_posts")) : ?>
    <?php get_template_part('templates/home', 'landing'); ?>
    <?php get_template_part('templates/home', 'lastposts'); ?>
    <?php get_template_part('templates/home', 'promote'); ?>
    <?php get_template_part('templates/home', 'categories'); ?>
  <?php else : ?>
    <?php get_template_part("templates/content", "navbar"); ?>
    <?php get_template_part('templates/blog', 'landing'); ?>
    <?php get_template_part('templates/archive', 'pageholder'); ?>
  <?php endif; ?>
<?php get_footer(); ?>