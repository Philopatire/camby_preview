<?php 
  global $current_user;
  if (post_password_required()) return;
?>
  <div class="comments-holder">
    <div class="comments-list">
      <?php wp_list_comments(["callback" => "custom_comments" ]); ?>
    </div>
    <div class="leave-comment-holder">
      <?php
        comment_form([
          "logged_in_as" => is_user_logged_in() ? "<div class='logged-in-as'>" . get_avatar(get_current_user_id()) . $current_user->display_name . "</div>" : "",
          "label_submit" => "Send",
          'title_reply' => "Leave a comment",
          "comment_field" => '<textarea id="comment" name="comment" cols="45" rows="8" maxlength="65525" required="required" placeholder="Comment*"></textarea>'
        ]); 
      ?>
    </div>

  </div>
  <!-- -->